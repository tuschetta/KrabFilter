package com.grabfilter

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.SharedPreferences
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class GrabAccessibilityService : AccessibilityService() {

    companion object {
        // Grab Driver app package names (different versions/regions)
        val GRAB_PACKAGES = setOf(
            "com.grabtaxi.driver",
            "com.grab.driver",
            "com.grabtaxi.driver2",
            "com.grabtaxi.driverapp"
        )

        // Regex to find distance in Thai and English format
        // Matches: "3.5 กม.", "5 กม", "3.5 km", "3.5km"
        val DISTANCE_REGEX = Regex(
            """(\d+\.?\d*)\s*(กม\.?|km|กิโล)""",
            RegexOption.IGNORE_CASE
        )
    }

    private lateinit var prefs: SharedPreferences
    private var overlayManager: OverlayManager? = null
    private var lastProcessedDistance: Float = -1f
    private var lastProcessTime: Long = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = getSharedPreferences("grabfilter_prefs", Context.MODE_PRIVATE)
        overlayManager = OverlayManager(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        // Only process events from Grab Driver app
        val packageName = event.packageName?.toString() ?: return
        if (!GRAB_PACKAGES.any { packageName.startsWith(it) }) return

        // Only process window change events
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        // Throttle: don't process more than once per second
        val now = System.currentTimeMillis()
        if (now - lastProcessTime < 1000) return
        lastProcessTime = now

        // Scan the window for distance text
        val rootNode = rootInActiveWindow ?: return
        val distanceInfo = findDistanceInNode(rootNode)

        if (distanceInfo != null) {
            val (distance, rawText) = distanceInfo

            // Don't show same result twice in a row
            if (Math.abs(distance - lastProcessedDistance) < 0.01f) return
            lastProcessedDistance = distance

            val maxDistance = prefs.getInt("max_distance_km", 5).toFloat()
            val isAcceptable = distance <= maxDistance
            val soundEnabled = prefs.getBoolean("sound_enabled", true)
            val vibrateEnabled = prefs.getBoolean("vibrate_enabled", true)

            overlayManager?.show(
                isAcceptable = isAcceptable,
                distance = distance,
                maxDistance = maxDistance,
                playSound = soundEnabled,
                vibrate = vibrateEnabled
            )
        }
    }

    private fun findDistanceInNode(node: AccessibilityNodeInfo?): Pair<Float, String>? {
        if (node == null) return null

        // Check this node's text
        val text = node.text?.toString()
        if (!text.isNullOrBlank()) {
            val match = DISTANCE_REGEX.find(text)
            if (match != null) {
                val distanceValue = match.groupValues[1].toFloatOrNull()
                if (distanceValue != null && distanceValue > 0f && distanceValue < 100f) {
                    return Pair(distanceValue, text)
                }
            }
        }

        // Check content description
        val contentDesc = node.contentDescription?.toString()
        if (!contentDesc.isNullOrBlank()) {
            val match = DISTANCE_REGEX.find(contentDesc)
            if (match != null) {
                val distanceValue = match.groupValues[1].toFloatOrNull()
                if (distanceValue != null && distanceValue > 0f && distanceValue < 100f) {
                    return Pair(distanceValue, contentDesc)
                }
            }
        }

        // Recursively check children
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            val result = findDistanceInNode(child)
            child?.recycle()
            if (result != null) return result
        }

        return null
    }

    override fun onInterrupt() {
        overlayManager?.hide()
    }

    override fun onDestroy() {
        super.onDestroy()
        overlayManager?.hide()
    }
}
