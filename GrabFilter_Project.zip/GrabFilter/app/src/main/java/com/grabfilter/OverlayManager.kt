package com.grabfilter

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.sin

class OverlayManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var overlayView: LinearLayout? = null
    private var dismissRunnable: Runnable? = null

    fun show(
        isAcceptable: Boolean,
        distance: Float,
        maxDistance: Float,
        playSound: Boolean,
        vibrate: Boolean
    ) {
        if (!canDrawOverlay()) return

        handler.post {
            // Remove existing overlay if any
            hide()

            // Create overlay view
            val layout = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(40, 30, 40, 30)

                if (isAcceptable) {
                    setBackgroundColor(Color.parseColor("#CC004400"))
                } else {
                    setBackgroundColor(Color.parseColor("#CC440000"))
                }
            }

            // Big icon and result text
            val tvResult = TextView(context).apply {
                text = if (isAcceptable) "✅  ไปได้!" else "❌  ไกลเกิน!"
                textSize = 36f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }

            // Distance detail
            val tvDistance = TextView(context).apply {
                text = "ระยะ: ${formatDistance(distance)} กม.  |  สูงสุด: ${maxDistance.toInt()} กม."
                textSize = 16f
                setTextColor(if (isAcceptable) Color.parseColor("#88FF88") else Color.parseColor("#FF8888"))
                gravity = Gravity.CENTER
                setPadding(0, 8, 0, 0)
            }

            layout.addView(tvResult)
            layout.addView(tvDistance)

            // Window layout params - floating over all apps
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = 80  // Slightly below status bar
            }

            windowManager.addView(layout, params)
            overlayView = layout

            // Auto-dismiss after 5 seconds
            dismissRunnable = Runnable { hide() }
            handler.postDelayed(dismissRunnable!!, 5000)
        }

        // Play sound
        if (playSound) {
            if (isAcceptable) playGreenSound() else playRedSound()
        }

        // Vibrate
        if (vibrate) {
            if (isAcceptable) vibrateGreen() else vibrateRed()
        }
    }

    fun hide() {
        handler.post {
            overlayView?.let {
                try {
                    windowManager.removeView(it)
                } catch (e: Exception) {
                    // View already removed
                }
                overlayView = null
            }
            dismissRunnable?.let { handler.removeCallbacks(it) }
        }
    }

    private fun canDrawOverlay(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else true
    }

    private fun formatDistance(distance: Float): String {
        return if (distance == distance.toLong().toFloat()) {
            distance.toInt().toString()
        } else {
            String.format("%.1f", distance)
        }
    }

    // ---- SOUND GENERATION ----
    // Generate tones programmatically (no resource files needed)

    private fun playGreenSound() {
        Thread {
            // Short, happy double-beep (high pitch)
            playTone(frequency = 880f, durationMs = 150)
            Thread.sleep(80)
            playTone(frequency = 1100f, durationMs = 200)
        }.start()
    }

    private fun playRedSound() {
        Thread {
            // Long, low warning beep
            playTone(frequency = 440f, durationMs = 400)
            Thread.sleep(100)
            playTone(frequency = 350f, durationMs = 400)
        }.start()
    }

    private fun playTone(frequency: Float, durationMs: Int) {
        val sampleRate = 44100
        val numSamples = sampleRate * durationMs / 1000
        val buffer = ShortArray(numSamples)
        val twoPiF = 2.0 * Math.PI * frequency / sampleRate

        // Generate sine wave with fade in/out to avoid clicks
        for (i in 0 until numSamples) {
            val envelope = when {
                i < numSamples * 0.1 -> i / (numSamples * 0.1)
                i > numSamples * 0.9 -> (numSamples - i) / (numSamples * 0.1)
                else -> 1.0
            }
            buffer[i] = (sin(twoPiF * i) * 32767 * envelope * 0.7).toInt().toShort()
        }

        val audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(buffer.size * 2)
            .build()

        audioTrack.write(buffer, 0, buffer.size)
        audioTrack.play()
        Thread.sleep(durationMs.toLong() + 50)
        audioTrack.release()
    }

    // ---- VIBRATION ----

    private fun vibrateGreen() {
        vibrate(longArrayOf(0, 100, 50, 100))  // Two short pulses
    }

    private fun vibrateRed() {
        vibrate(longArrayOf(0, 500, 100, 500))  // Two long pulses
    }

    private fun vibrate(pattern: LongArray) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vibratorManager.defaultVibrator.vibrate(
                    VibrationEffect.createWaveform(pattern, -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(pattern, -1)
                }
            }
        } catch (e: Exception) {
            // Vibration not available
        }
    }
}
