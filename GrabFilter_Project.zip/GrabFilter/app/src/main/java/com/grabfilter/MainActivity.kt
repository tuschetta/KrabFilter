package com.grabfilter

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var tvStatus: TextView
    private lateinit var tvDistanceValue: TextView
    private lateinit var seekDistance: SeekBar
    private lateinit var switchSound: Switch
    private lateinit var switchVibrate: Switch
    private lateinit var btnAccessibility: Button
    private lateinit var btnOverlay: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("grabfilter_prefs", Context.MODE_PRIVATE)

        // Init views
        tvStatus = findViewById(R.id.tvStatus)
        tvDistanceValue = findViewById(R.id.tvDistanceValue)
        seekDistance = findViewById(R.id.seekDistance)
        switchSound = findViewById(R.id.switchSound)
        switchVibrate = findViewById(R.id.switchVibrate)
        btnAccessibility = findViewById(R.id.btnAccessibility)
        btnOverlay = findViewById(R.id.btnOverlay)

        // Load saved settings
        val savedDistance = prefs.getInt("max_distance_km", 5)
        seekDistance.progress = savedDistance
        tvDistanceValue.text = "$savedDistance กม."
        switchSound.isChecked = prefs.getBoolean("sound_enabled", true)
        switchVibrate.isChecked = prefs.getBoolean("vibrate_enabled", true)

        // SeekBar: min is 1
        seekDistance.max = 19 // 1 to 20
        seekDistance.progress = savedDistance - 1

        seekDistance.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val km = progress + 1
                tvDistanceValue.text = "$km กม."
                prefs.edit().putInt("max_distance_km", km).apply()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        switchSound.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("sound_enabled", isChecked).apply()
        }

        switchVibrate.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("vibrate_enabled", isChecked).apply()
        }

        // Permission buttons
        btnAccessibility.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        }

        btnOverlay.setOnClickListener {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val accessibilityEnabled = isAccessibilityServiceEnabled()
        val overlayEnabled = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else true

        when {
            accessibilityEnabled && overlayEnabled -> {
                tvStatus.text = "🟢 กำลังทำงาน - พร้อมรับมือ!"
                tvStatus.setTextColor(0xFF00C853.toInt())
            }
            !accessibilityEnabled -> {
                tvStatus.text = "🔴 กรุณากด ปุ่ม 1 ด้านล่างก่อน"
                tvStatus.setTextColor(0xFFFF5555.toInt())
            }
            !overlayEnabled -> {
                tvStatus.text = "🟡 กรุณากด ปุ่ม 2 ด้านล่างก่อน"
                tvStatus.setTextColor(0xFFFFCC00.toInt())
            }
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return enabledServices.any { it.resolveInfo.serviceInfo.packageName == packageName }
    }
}
